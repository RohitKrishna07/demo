package com.fullstacktraining.bookmanagement.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fullstacktraining.bookmanagement.entity.Book;

@Repository
public interface BookRepo extends CrudRepository<Book, Integer> {

}
